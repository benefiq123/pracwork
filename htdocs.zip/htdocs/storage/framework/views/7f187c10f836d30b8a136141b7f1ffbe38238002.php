<?php $__env->startSection('content'); ?>

    <link rel="stylesheet" href="<?php echo e(asset('resources/css/admin.css')); ?>">
    <div class="orders-wrapper">
        <div class="orders-head">
            <div class="orders-head-id order-cell">ID</div>
            <div class="orders-head-name order-cell">Имя</div>
            <div class="orders-head-description order-cell">Описание</div>
            <div class="orders-head-phone order-cell">Телефон</div>
            <div class="orders-head-status order-cell">Статус</div>
        </div>
        <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="order">
                    <div class="order-id order-cell"><?php echo e($order->id); ?></div>
                    <div class="order-name order-cell"><?php echo e($order->name); ?></div>
                    <div class="order-description order-cell"><?php echo e($order->description); ?></div>
                    <div class="order-phone order-cell"><?php echo e($order->phone); ?></div>
                    <div class="order-status order-cell">
                        <div class="status-text"><?php echo e($order->status); ?></div>
                        <form action="<?php echo e(route('adminPost', ['id' => $order->id])); ?>" class="change-status-form" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('post'); ?>
                            <select name="changeStatus" id="change-status">
                                <option value="В работе">В работе</option>
                                <option value="Готово">Готово</option>
                            </select>
                            <button class="submit-change" type="submit">Изменить статус</button>
                        </form>
                    </div>
                </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\OSPanel\domains\pracwork\resources\views/admin.blade.php ENDPATH**/ ?>