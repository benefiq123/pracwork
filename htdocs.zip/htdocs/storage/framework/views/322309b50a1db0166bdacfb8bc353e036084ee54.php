<?php $__env->startSection('content'); ?>

    <link rel="stylesheet" href="<?php echo e(asset('resources/css/registration.css')); ?>">
    <form action="<?php echo e(route('registrationPost')); ?>" method="POST" class="registration-form">
        <?php echo csrf_field(); ?>
        <?php echo method_field('post'); ?>
        <div class="name-group">
            <label for="name">Ваше имя</label><br>
            <input type="text" id="name" name="name">
        </div>
        <div class="login-group">
            <label for="login">Логин</label><br>
            <input type="text" id="login" name="login">
        </div>
        <div class="phone-group">
            <label for="phone">Телефон</label><br>
            <input type="tel" id="phone" name="phone">
        </div>
        <div class="password-group">
            <label for="password">Пароль</label><br>
            <input type="password" id="password" name="password">
        </div>
        <button type="submit" class="submit">Регистрация</button>
    </form>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\OSPanel\domains\pracwork\resources\views/registration.blade.php ENDPATH**/ ?>