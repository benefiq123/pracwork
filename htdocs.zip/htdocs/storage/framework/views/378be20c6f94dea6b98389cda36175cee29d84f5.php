<?php $__env->startSection('content'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('resources/css/home.css')); ?>">

    <h1 class="body-title">AutoFIX - лучший автосервис для вашей машины!</h1>

    <img src="<?php echo e(asset('resources/img/20945487.jpg')); ?>" alt="" class="body-image">

    <p class="body-subtitle">
        Автосервис AutoFIX поможет вам при любой неисправности вашего автомобиля!<br>
        Диагностика, ремонт, измерение уровня и замена всех жидкостей в авто;<br>
        Нам доверяют - оставьте <a <?php if(auth()->guard()->guest()): ?> href="<?php echo e(route('login')); ?>" <?php else: ?> href="<?php echo e(route('makeOrder')); ?>" <?php endif; ?>">заявку</a> у нас на сайте и мы свяжемся с вами!
    </p>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\OSPanel\domains\workprac\resources\views/home.blade.php ENDPATH**/ ?>