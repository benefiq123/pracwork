<?php $__env->startSection('content'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('resources/css/makeOrder.css')); ?>">

    <form action="<?php echo e(route('makeOrderPost')); ?>" method="POST" class="make-order-form" id="makeOrderForm">
        <?php echo csrf_field(); ?>
        <?php echo method_field('post'); ?>
        <div class="description-group">
            <label for="description" class="label" style="font-size: 18px; font-weight: bold;">Описание проблемы</label><br>
            <textarea id="description" name="description" class="make-order-input input-description" form="makeOrderForm"></textarea>
        </div>
        <div class="model-group">
            <label for="model" class="label" style="font-size: 18px; font-weight: bold;">Модель машины</label><br>
            <input type="text" id="model" name="model" class="make-order-input input-model">
        </div>
        <button type="submit" class="submit">Оставить заявку</button>
    </form>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\OSPanel\domains\pracwork\resources\views/makeOrder.blade.php ENDPATH**/ ?>