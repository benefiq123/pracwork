<?php $__env->startSection('content'); ?>

    <link rel="stylesheet" href="<?php echo e(asset('resources/css/login.css')); ?>">
    <form action="<?php echo e(route('loginPost')); ?>" method="POST" class="login-form">
        <?php echo csrf_field(); ?>
        <?php echo method_field('post'); ?>
        <div class="login-group">
            <label for="login">Логин</label>
            <input type="text" id="login" name="login">
        </div>
        <div class="password-group">
            <label for="password">Пароль</label>
            <input type="password" id="password" name="password">
        </div>
        <button type="submit" class="submit">Вход</button>
    </form>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\MAMP\htdocs\resources\views/login.blade.php ENDPATH**/ ?>