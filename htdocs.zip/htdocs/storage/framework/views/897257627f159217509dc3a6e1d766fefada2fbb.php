<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <link rel="stylesheet" href="<?php echo e(asset('resources/css/layout.css')); ?>">
</head>
<body>
    <header class="header">
        <div class="header-wrapper">
            <div class="header-menu">
                <a href="<?php echo e(route('home')); ?>" class="text-logo">АвтоFIX</a>
                <ul class="navigation">
                    <li class="navigation-item"><a href="<?php echo e(route('home')); ?>" class="item-a">Главная</a></li>
                    <li class="navigation-item"><a href="<?php echo e(route('about')); ?>" class="item-a">О нас</a></li>
                    <li class="navigation-item"><a <?php if(auth()->guard()->guest()): ?> href="<?php echo e(route('login')); ?>" <?php else: ?> href="<?php echo e(route('makeOrder')); ?>" <?php endif; ?> class="item-a">Оставить заявку</a></li>
                </ul>
                <div class="auth-group">
                    <?php if(auth()->guard()->guest()): ?>
                        <a href="<?php echo e(route('registration')); ?>" class="registration">Регистрация</a>
                        <a href="<?php echo e(route('login')); ?>" class="login">Авторизация</a>
                    <?php else: ?>
                        <a href="<?php echo e(route('myOrders')); ?>" class="my-orders">Мои заявки</a>
                        <a href="<?php echo e(route('logout')); ?>" class="logout">Выйти</a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </header>
    <div class="body-wrapper">
        <?php echo $__env->yieldContent('content'); ?>
    </div>
</body>
</html>
<?php /**PATH E:\MAMP\htdocs\resources\views/layout.blade.php ENDPATH**/ ?>